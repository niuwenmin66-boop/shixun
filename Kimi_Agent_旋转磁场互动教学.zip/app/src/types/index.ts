// 三相电流状态
export interface PhaseCurrents {
  a: number; // A相电流
  b: number; // B相电流
  c: number; // C相电流
}

// 磁场矢量
export interface MagneticVector {
  magnitude: number; // 幅值
  angle: number;     // 角度 (度)
}

// 合成磁场
export interface ResultantField {
  magnitude: number; // 幅值
  angle: number;     // 角度 (度)
}

// 应用状态
export interface AppState {
  frequency: number;      // 频率 (Hz)
  polePairs: number;      // 极对数
  amplitude: number;      // 电流幅值
  isPlaying: boolean;     // 是否播放
  direction: 1 | -1;      // 旋转方向 (1: 正转, -1: 反转)
  currentTime: number;    // 当前时间 (用于动画)
}

// 滑块配置
export interface SliderConfig {
  min: number;
  max: number;
  step: number;
  defaultValue: number;
}

// 极对数选项
export interface PolePairOption {
  value: number;
  label: string;
}
