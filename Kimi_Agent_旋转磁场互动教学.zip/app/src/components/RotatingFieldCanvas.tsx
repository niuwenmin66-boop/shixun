import { useEffect, useRef, useCallback } from 'react';
import type { ResultantField } from '@/types';

interface RotatingFieldCanvasProps {
  resultantField: ResultantField;
  showTrajectory: boolean;
}

export function RotatingFieldCanvas({ resultantField, showTrajectory }: RotatingFieldCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const trajectoryRef = useRef<{ x: number; y: number }[]>([]);
  const maxTrajectoryPoints = 100;

  const colors = {
    resultant: '#f59e0b', // 琥珀金
    trajectory: 'rgba(245, 158, 11, 0.3)',
    stator: 'rgba(255, 255, 255, 0.2)',
    grid: 'rgba(255, 255, 255, 0.05)',
    text: 'rgba(255, 255, 255, 0.6)',
    direction: 'rgba(59, 130, 246, 0.5)',
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 设置画布尺寸
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    if (canvas.width !== rect.width * dpr || canvas.height !== rect.height * dpr) {
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    }

    const width = rect.width;
    const height = rect.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.38;

    // 清空画布
    ctx.clearRect(0, 0, width, height);

    // 绘制网格
    ctx.strokeStyle = colors.grid;
    ctx.lineWidth = 1;
    
    // 同心圆
    for (let i = 1; i <= 3; i++) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * (i / 3), 0, Math.PI * 2);
      ctx.stroke();
    }

    // 十字线
    ctx.beginPath();
    ctx.moveTo(centerX - radius * 1.1, centerY);
    ctx.lineTo(centerX + radius * 1.1, centerY);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(centerX, centerY - radius * 1.1);
    ctx.lineTo(centerX, centerY + radius * 1.1);
    ctx.stroke();

    // 绘制方向标记
    ctx.font = 'bold 14px Inter, sans-serif';
    ctx.fillStyle = colors.text;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // N极 (上方)
    ctx.fillText('N', centerX, centerY - radius * 1.15);
    // S极 (下方)
    ctx.fillText('S', centerX, centerY + radius * 1.15);
    // E极 (右方)
    ctx.fillText('E', centerX + radius * 1.15, centerY);
    // W极 (左方)
    ctx.fillText('W', centerX - radius * 1.15, centerY);

    // 计算合成矢量终点
    const angleRad = (resultantField.angle * Math.PI) / 180;
    const arrowLength = radius * 0.9;
    const endX = centerX + arrowLength * Math.cos(angleRad);
    const endY = centerY + arrowLength * Math.sin(angleRad);

    // 添加到轨迹
    trajectoryRef.current.push({ x: endX, y: endY });
    if (trajectoryRef.current.length > maxTrajectoryPoints) {
      trajectoryRef.current.shift();
    }

    // 绘制轨迹
    if (showTrajectory && trajectoryRef.current.length > 1) {
      ctx.strokeStyle = colors.trajectory;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      
      ctx.beginPath();
      trajectoryRef.current.forEach((point, index) => {
        if (index === 0) {
          ctx.moveTo(point.x, point.y);
        } else {
          ctx.lineTo(point.x, point.y);
        }
      });
      ctx.stroke();
    }

    // 绘制旋转圆
    ctx.strokeStyle = colors.resultant;
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.arc(centerX, centerY, arrowLength, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // 绘制合成矢量
    ctx.strokeStyle = colors.resultant;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(endX, endY);
    ctx.stroke();

    // 绘制矢量箭头
    const arrowHeadLength = 15;
    const arrowAngle = Math.atan2(endY - centerY, endX - centerX);
    
    ctx.fillStyle = colors.resultant;
    ctx.beginPath();
    ctx.moveTo(endX, endY);
    ctx.lineTo(
      endX - arrowHeadLength * Math.cos(arrowAngle - Math.PI / 6),
      endY - arrowHeadLength * Math.sin(arrowAngle - Math.PI / 6)
    );
    ctx.lineTo(
      endX - arrowHeadLength * Math.cos(arrowAngle + Math.PI / 6),
      endY - arrowHeadLength * Math.sin(arrowAngle + Math.PI / 6)
    );
    ctx.closePath();
    ctx.fill();

    // 绘制中心发光效果
    const gradient = ctx.createRadialGradient(
      centerX, centerY, 0,
      centerX, centerY, 20
    );
    gradient.addColorStop(0, 'rgba(245, 158, 11, 0.5)');
    gradient.addColorStop(1, 'transparent');
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(centerX, centerY, 20, 0, Math.PI * 2);
    ctx.fill();

    // 绘制中心点
    ctx.fillStyle = colors.resultant;
    ctx.beginPath();
    ctx.arc(centerX, centerY, 6, 0, Math.PI * 2);
    ctx.fill();

    // 绘制角度标记
    ctx.font = '12px Inter, sans-serif';
    ctx.fillStyle = colors.text;
    ctx.textAlign = 'left';
    ctx.fillText(`θ = ${resultantField.angle.toFixed(1)}°`, 15, height - 15);

  }, [resultantField, showTrajectory]);

  useEffect(() => {
    draw();
  }, [draw]);

  useEffect(() => {
    const handleResize = () => draw();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [draw]);

  // 当方向改变时清空轨迹
  useEffect(() => {
    trajectoryRef.current = [];
  }, [resultantField.angle]);

  return (
    <div className="canvas-container" style={{ height: '350px' }}>
      <canvas 
        ref={canvasRef} 
        className="w-full h-full"
        style={{ display: 'block' }}
      />
    </div>
  );
}
