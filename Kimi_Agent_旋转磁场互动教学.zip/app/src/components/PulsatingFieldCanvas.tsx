import { useEffect, useRef, useCallback } from 'react';
import type { PhaseCurrents } from '@/types';

interface PulsatingFieldCanvasProps {
  currents: PhaseCurrents;
  amplitude: number;
}

export function PulsatingFieldCanvas({ currents, amplitude }: PulsatingFieldCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // 颜色配置
  const colors = {
    a: '#ef4444',
    b: '#22c55e',
    c: '#3b82f6',
    stator: 'rgba(255, 255, 255, 0.3)',
    coil: 'rgba(255, 255, 255, 0.5)',
    text: 'rgba(255, 255, 255, 0.7)',
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 设置画布尺寸
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    if (canvas.width !== rect.width * dpr || canvas.height !== rect.height * dpr) {
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    }

    const width = rect.width;
    const height = rect.height;
    const centerX = width / 2;
    const centerY = height / 2;

    // 清空画布
    ctx.clearRect(0, 0, width, height);

    // 定子圆参数
    const statorRadius = Math.min(width, height) * 0.35;

    // 绘制定子圆
    ctx.strokeStyle = colors.stator;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(centerX, centerY, statorRadius, 0, Math.PI * 2);
    ctx.stroke();

    // 绘制中心点
    ctx.fillStyle = colors.stator;
    ctx.beginPath();
    ctx.arc(centerX, centerY, 4, 0, Math.PI * 2);
    ctx.fill();

    // 绕组配置 (空间角度)
    const windings = [
      { name: 'AX', phase: 'a' as const, angle: 0, label: 'A' },
      { name: 'BY', phase: 'b' as const, angle: -120, label: 'B' },
      { name: 'CZ', phase: 'c' as const, angle: -240, label: 'C' },
    ];

    // 绘制绕组
    windings.forEach((winding) => {
      const angleRad = (winding.angle * Math.PI) / 180;
      const x1 = centerX + statorRadius * 0.6 * Math.cos(angleRad);
      const y1 = centerY + statorRadius * 0.6 * Math.sin(angleRad);
      const x2 = centerX + statorRadius * Math.cos(angleRad);
      const y2 = centerY + statorRadius * Math.sin(angleRad);

      // 绘制绕组线圈
      ctx.strokeStyle = colors.coil;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();

      // 绘制绕组标签
      const labelX = centerX + statorRadius * 1.15 * Math.cos(angleRad);
      const labelY = centerY + statorRadius * 1.15 * Math.sin(angleRad);
      
      ctx.font = 'bold 14px Inter, sans-serif';
      ctx.fillStyle = colors.text;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(winding.label, labelX, labelY);

      // 绘制X/Y/Z标签 (绕组另一端)
      const endLabelX = centerX + statorRadius * 0.4 * Math.cos(angleRad);
      const endLabelY = centerY + statorRadius * 0.4 * Math.sin(angleRad);
      ctx.font = '12px Inter, sans-serif';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.fillText(winding.name[1], endLabelX, endLabelY);
    });

    // 绘制脉振磁场矢量
    const maxArrowLength = statorRadius * 0.5;

    windings.forEach((winding) => {
      const current = currents[winding.phase];
      const angleRad = (winding.angle * Math.PI) / 180;
      
      // 矢量长度与电流成正比
      const arrowLength = (current / amplitude) * maxArrowLength;
      
      // 矢量颜色
      const color = colors[winding.phase];
      
      // 绘制矢量 (从中心向外)
      if (Math.abs(arrowLength) > 2) {
        const endX = centerX + arrowLength * Math.cos(angleRad);
        const endY = centerY + arrowLength * Math.sin(angleRad);

        // 矢量线
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(endX, endY);
        ctx.stroke();

        // 箭头
        const arrowHeadLength = 10;
        const arrowAngle = Math.atan2(endY - centerY, endX - centerX);
        
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(endX, endY);
        ctx.lineTo(
          endX - arrowHeadLength * Math.cos(arrowAngle - Math.PI / 6),
          endY - arrowHeadLength * Math.sin(arrowAngle - Math.PI / 6)
        );
        ctx.lineTo(
          endX - arrowHeadLength * Math.cos(arrowAngle + Math.PI / 6),
          endY - arrowHeadLength * Math.sin(arrowAngle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fill();

        // 电流值标签
        const valueX = centerX + (arrowLength * 0.5) * Math.cos(angleRad);
        const valueY = centerY + (arrowLength * 0.5) * Math.sin(angleRad);
        
        ctx.font = 'bold 12px Inter, sans-serif';
        ctx.fillStyle = color;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // 偏移标签位置避免重叠
        const offsetX = -15 * Math.sin(angleRad);
        const offsetY = 15 * Math.cos(angleRad);
        ctx.fillText(current.toFixed(2), valueX + offsetX, valueY + offsetY);
      }
    });

    // 绘制图例
    const legendY = height - 30;
    const legendItems = [
      { label: 'A相', color: colors.a },
      { label: 'B相', color: colors.b },
      { label: 'C相', color: colors.c },
    ];

    let legendX = centerX - 80;
    legendItems.forEach((item) => {
      // 色块
      ctx.fillStyle = item.color;
      ctx.fillRect(legendX, legendY - 5, 12, 12);
      
      // 标签
      ctx.font = '12px Inter, sans-serif';
      ctx.fillStyle = colors.text;
      ctx.textAlign = 'left';
      ctx.fillText(item.label, legendX + 18, legendY + 2);
      
      legendX += 60;
    });

  }, [currents, amplitude]);

  useEffect(() => {
    draw();
  }, [draw]);

  useEffect(() => {
    const handleResize = () => draw();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [draw]);

  return (
    <div className="canvas-container" style={{ height: '320px' }}>
      <canvas 
        ref={canvasRef} 
        className="w-full h-full"
        style={{ display: 'block' }}
      />
    </div>
  );
}
