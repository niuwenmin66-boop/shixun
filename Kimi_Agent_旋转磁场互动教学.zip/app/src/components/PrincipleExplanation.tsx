import { useState } from 'react';
import { ChevronDown, ChevronUp, Lightbulb, Zap, Rotate3D, Gauge } from 'lucide-react';

interface Step {
  id: number;
  title: string;
  icon: React.ReactNode;
  content: string;
  details: string[];
  color: string;
}

const steps: Step[] = [
  {
    id: 1,
    title: '三相绕组空间分布',
    icon: <Rotate3D className="w-5 h-5" />,
    content: '定子铁芯内嵌有三相对称绕组 AX、BY、CZ，它们在空间上互差 120° 电角度。',
    details: [
      'A相绕组 AX 位于 0° 位置',
      'B相绕组 BY 位于 -120° 位置',
      'C相绕组 CZ 位于 -240° (或 +120°) 位置',
      '三相绕组结构完全相同，空间对称分布',
    ],
    color: '#3b82f6',
  },
  {
    id: 2,
    title: '三相电流时间相位差',
    icon: <Zap className="w-5 h-5" />,
    content: '三相绕组通入对称三相交流电，各相电流在时间上互差 120° 相位。',
    details: [
      'iₐ = Iₘ sin(ωt) - A相电流',
      'iᵦ = Iₘ sin(ωt - 120°) - B相电流滞后A相120°',
      'iᶜ = Iₘ sin(ωt - 240°) - C相电流滞后A相240°',
      '三相对称：iₐ + iᵦ + iᶜ = 0',
    ],
    color: '#22c55e',
  },
  {
    id: 3,
    title: '脉振磁场的合成',
    icon: <Lightbulb className="w-5 h-5" />,
    content: '每相绕组产生脉振磁场，三个脉振磁场合成后形成旋转磁场。',
    details: [
      '每相脉振磁场方向固定，大小随电流变化',
      'A相磁场在 0° 方向脉振',
      'B相磁场在 -120° 方向脉振',
      'C相磁场在 -240° 方向脉振',
      '合成磁场幅值恒定，方向匀速旋转',
    ],
    color: '#ef4444',
  },
  {
    id: 4,
    title: '同步转速',
    icon: <Gauge className="w-5 h-5" />,
    content: '旋转磁场的转速称为同步转速，与电源频率和极对数有关。',
    details: [
      '同步转速公式：n₁ = 60f / p',
      'f：电源频率 (Hz)',
      'p：极对数',
      'n₁：同步转速 (r/min)',
      '频率越高，转速越快；极对数越多，转速越慢',
    ],
    color: '#f59e0b',
  },
];

export function PrincipleExplanation() {
  const [expandedSteps, setExpandedSteps] = useState<number[]>([1]);

  const toggleStep = (stepId: number) => {
    setExpandedSteps((prev) =>
      prev.includes(stepId)
        ? prev.filter((id) => id !== stepId)
        : [...prev, stepId]
    );
  };

  return (
    <div className="space-y-3">
      {steps.map((step) => {
        const isExpanded = expandedSteps.includes(step.id);
        
        return (
          <div
            key={step.id}
            className={`
              rounded-lg border transition-all duration-300 overflow-hidden
              ${isExpanded 
                ? 'bg-white/8 border-white/20' 
                : 'bg-white/5 border-white/10 hover:bg-white/8 hover:border-white/15'
              }
            `}
          >
            {/* 步骤头部 */}
            <button
              onClick={() => toggleStep(step.id)}
              className="w-full px-4 py-3 flex items-center gap-3 text-left"
            >
              {/* 步骤编号 */}
              <div 
                className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                style={{ 
                  backgroundColor: `${step.color}30`,
                  color: step.color,
                }}
              >
                {step.id}
              </div>

              {/* 图标 */}
              <div 
                className="shrink-0"
                style={{ color: step.color }}
              >
                {step.icon}
              </div>

              {/* 标题 */}
              <span className="flex-1 font-medium text-white/90">
                {step.title}
              </span>

              {/* 展开/收起图标 */}
              <div className="text-white/50">
                {isExpanded ? (
                  <ChevronUp className="w-5 h-5" />
                ) : (
                  <ChevronDown className="w-5 h-5" />
                )}
              </div>
            </button>

            {/* 展开内容 */}
            <div 
              className={`
                overflow-hidden transition-all duration-300
                ${isExpanded ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}
              `}
            >
              <div className="px-4 pb-4 pt-0">
                {/* 主要内容 */}
                <p className="text-sm text-white/70 mb-3 pl-11">
                  {step.content}
                </p>

                {/* 详细列表 */}
                <ul className="space-y-2 pl-11">
                  {step.details.map((detail, idx) => (
                    <li 
                      key={idx}
                      className="flex items-start gap-2 text-sm text-white/60"
                    >
                      <span 
                        className="w-1.5 h-1.5 rounded-full mt-2 shrink-0"
                        style={{ backgroundColor: step.color }}
                      />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        );
      })}

      {/* 总结 */}
      <div className="mt-4 p-4 bg-gradient-to-r from-[#3b82f6]/10 via-[#8b5cf6]/10 to-[#f59e0b]/10 rounded-lg border border-white/10">
        <div className="flex items-start gap-3">
          <Lightbulb className="w-5 h-5 text-[#f59e0b] shrink-0 mt-0.5" />
          <div>
            <h4 className="font-medium text-white/90 mb-1">核心要点</h4>
            <p className="text-sm text-white/60">
              旋转磁场的产生是交流电机工作的基础。通过三相对称绕组通入三相对称电流，
              利用空间分布和时间相位的双重 120° 差异，使三个脉振磁场合成一个幅值恒定、
              匀速旋转的合成磁场，从而驱动转子转动。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
