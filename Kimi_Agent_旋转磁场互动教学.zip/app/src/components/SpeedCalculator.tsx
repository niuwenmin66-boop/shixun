import { useState, useEffect } from 'react';
import { Calculator, Info } from 'lucide-react';

interface SpeedCalculatorProps {
  frequency: number;
  polePairs: number;
  syncSpeed: number;
}

export function SpeedCalculator({ frequency, polePairs, syncSpeed }: SpeedCalculatorProps) {
  const [displaySpeed, setDisplaySpeed] = useState(syncSpeed);
  const [isAnimating, setIsAnimating] = useState(false);

  // 当同步转速变化时，添加动画效果
  useEffect(() => {
    if (displaySpeed !== syncSpeed) {
      setIsAnimating(true);
      const timer = setTimeout(() => {
        setDisplaySpeed(syncSpeed);
        setIsAnimating(false);
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [syncSpeed, displaySpeed]);

  return (
    <div className="space-y-4">
      {/* 公式展示 */}
      <div className="p-4 bg-black/30 rounded-lg border border-white/5">
        <div className="flex items-center gap-2 mb-3">
          <Calculator className="w-4 h-4 text-[#3b82f6]" />
          <span className="text-xs font-medium text-white/50 uppercase tracking-wider">
            同步转速公式
          </span>
        </div>
        
        <div className="formula text-center">
          <span className="text-white">n</span>
          <span className="text-white/50 text-sm">₁</span>
          <span className="text-white/60 mx-2">=</span>
          <span className="variable">60</span>
          <span className="text-white/60 mx-1">×</span>
          <span className="variable">f</span>
          <span className="text-white/60 mx-2">/</span>
          <span className="variable">p</span>
        </div>

        {/* 参数说明 */}
        <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
          <div className="p-2 bg-white/5 rounded">
            <span className="text-[#3b82f6] font-semibold">f</span>
            <span className="text-white/50 ml-1">电源频率 (Hz)</span>
          </div>
          <div className="p-2 bg-white/5 rounded">
            <span className="text-[#8b5cf6] font-semibold">p</span>
            <span className="text-white/50 ml-1">极对数</span>
          </div>
          <div className="p-2 bg-white/5 rounded">
            <span className="text-[#f59e0b] font-semibold">n₁</span>
            <span className="text-white/50 ml-1">同步转速 (r/min)</span>
          </div>
        </div>
      </div>

      {/* 实时计算 */}
      <div className="p-4 bg-gradient-to-br from-[#f59e0b]/10 to-transparent rounded-lg border border-[#f59e0b]/30">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-medium text-white/50 uppercase tracking-wider">
            实时计算
          </span>
          <div className="flex items-center gap-1 text-xs text-white/40">
            <Info className="w-3 h-3" />
            <span>自动更新</span>
          </div>
        </div>

        {/* 计算过程 */}
        <div className="text-center mb-4">
          <div className="text-lg text-white/70">
            <span className="mono">n₁</span>
            <span className="mx-2">=</span>
            <span className="mono text-[#3b82f6]">60</span>
            <span className="mx-1">×</span>
            <span className="mono text-[#3b82f6]">{frequency.toFixed(1)}</span>
            <span className="mx-2">/</span>
            <span className="mono text-[#8b5cf6]">{polePairs}</span>
          </div>
        </div>

        {/* 结果 */}
        <div className="text-center">
          <div 
            className={`
              inline-flex items-baseline gap-2 px-6 py-3 bg-[#f59e0b]/20 rounded-xl border border-[#f59e0b]/50
              transition-all duration-150
              ${isAnimating ? 'opacity-50 scale-95' : 'opacity-100 scale-100'}
            `}
          >
            <span className="mono text-4xl font-bold text-[#f59e0b]">
              {displaySpeed.toFixed(0)}
            </span>
            <span className="text-white/60 text-sm">r/min</span>
          </div>
        </div>

        {/* 说明文字 */}
        <div className="mt-4 text-xs text-white/50 text-center">
          当电源频率为 <span className="text-[#3b82f6]">{frequency.toFixed(1)} Hz</span>，
          极对数为 <span className="text-[#8b5cf6]">{polePairs}</span> 时，
          旋转磁场的同步转速为 <span className="text-[#f59e0b]">{displaySpeed.toFixed(0)} 转/分钟</span>
        </div>
      </div>

      {/* 极对数与转速关系 */}
      <div className="p-3 bg-white/5 rounded-lg">
        <div className="text-xs font-medium text-white/50 mb-2">
          不同极对数下的同步转速 (f = {frequency.toFixed(1)} Hz)
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 4].map((p) => {
            const speed = (60 * frequency) / p;
            const isActive = p === polePairs;
            return (
              <div 
                key={p}
                className={`
                  p-2 rounded text-center transition-all duration-200
                  ${isActive 
                    ? 'bg-[#3b82f6]/20 border border-[#3b82f6]/50' 
                    : 'bg-white/5 border border-transparent'
                  }
                `}
              >
                <div className="text-xs text-white/50">{p}对极</div>
                <div className={`mono text-sm font-semibold ${isActive ? 'text-[#3b82f6]' : 'text-white/70'}`}>
                  {speed.toFixed(0)}
                </div>
                <div className="text-xs text-white/40">r/min</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
