import { useState } from 'react';
import { useMagneticField } from '@/hooks/useMagneticField';
import { WaveformCanvas } from '@/components/WaveformCanvas';
import { PulsatingFieldCanvas } from '@/components/PulsatingFieldCanvas';
import { RotatingFieldCanvas } from '@/components/RotatingFieldCanvas';
import { ControlPanel } from '@/components/ControlPanel';
import { SpeedCalculator } from '@/components/SpeedCalculator';
import { PrincipleExplanation } from '@/components/PrincipleExplanation';
import { Activity, Settings, BookOpen, Calculator, Eye, EyeOff } from 'lucide-react';

function App() {
  const {
    state,
    currents,
    resultantField,
    syncSpeed,
    setFrequency,
    setPolePairs,
    setAmplitude,
    togglePlay,
    toggleDirection,
    reset,
  } = useMagneticField();

  const [showTrajectory, setShowTrajectory] = useState(true);

  return (
    <div className="min-h-screen bg-[#0a0a0f] grid-bg">
      {/* 页面标题 */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#3b82f6]/10 to-transparent" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
          <div className="text-center animate-fadeIn">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold gradient-text mb-4">
              旋转磁场产生原理
            </h1>
            <p className="text-lg sm:text-xl text-white/70 max-w-2xl mx-auto">
              三相定子绕组与交流电的魔法
            </p>
            <p className="mt-4 text-sm text-white/50 max-w-3xl mx-auto">
              通过交互式可视化，深入理解三相交流电机中旋转磁场的产生机制，
              探索空间分布、时间相位与合成磁场的奥秘。
            </p>
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {/* 第一行：三相波形 + 控制面板 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* 三相波形 */}
          <div className="lg:col-span-2 glass-card p-5 animate-fadeIn delay-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#3b82f6]" />
                <h2 className="text-lg font-semibold text-white/90">
                  三相交流电波形
                </h2>
              </div>
              <div className="flex items-center gap-4 text-xs">
                <span className="phase-label">
                  <span className="phase-dot phase-a" />
                  A相
                </span>
                <span className="phase-label">
                  <span className="phase-dot phase-b" />
                  B相
                </span>
                <span className="phase-label">
                  <span className="phase-dot phase-c" />
                  C相
                </span>
              </div>
            </div>
            <WaveformCanvas
              currents={currents}
              frequency={state.frequency}
              amplitude={state.amplitude}
              currentTime={state.currentTime}
              direction={state.direction}
            />
          </div>

          {/* 控制面板 */}
          <div className="glass-card p-5 animate-slideInRight delay-200">
            <div className="flex items-center gap-2 mb-4">
              <Settings className="w-5 h-5 text-[#8b5cf6]" />
              <h2 className="text-lg font-semibold text-white/90">
                参数控制
              </h2>
            </div>
            <ControlPanel
              frequency={state.frequency}
              polePairs={state.polePairs}
              amplitude={state.amplitude}
              isPlaying={state.isPlaying}
              direction={state.direction}
              onFrequencyChange={setFrequency}
              onPolePairsChange={setPolePairs}
              onAmplitudeChange={setAmplitude}
              onTogglePlay={togglePlay}
              onToggleDirection={toggleDirection}
              onReset={reset}
            />
          </div>
        </div>

        {/* 第二行：脉振磁场 + 合成旋转磁场 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* 脉振磁场 */}
          <div className="glass-card p-5 animate-fadeIn delay-300">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#22c55e]" />
                <h2 className="text-lg font-semibold text-white/90">
                  空间分布的脉振磁场
                </h2>
              </div>
              <div className="text-xs text-white/50">
                定子绕组俯视图
              </div>
            </div>
            <PulsatingFieldCanvas
              currents={currents}
              amplitude={state.amplitude}
            />
            <div className="mt-3 text-xs text-white/50 text-center">
              三个脉振磁场方向固定，幅值随各相电流变化
            </div>
          </div>

          {/* 合成旋转磁场 */}
          <div className="glass-card p-5 animate-fadeIn delay-400">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#f59e0b]" />
                <h2 className="text-lg font-semibold text-white/90">
                  合成旋转磁场
                </h2>
              </div>
              <button
                onClick={() => setShowTrajectory(!showTrajectory)}
                className="flex items-center gap-1.5 text-xs text-white/50 hover:text-white/80 transition-colors"
              >
                {showTrajectory ? (
                  <>
                    <EyeOff className="w-4 h-4" />
                    隐藏轨迹
                  </>
                ) : (
                  <>
                    <Eye className="w-4 h-4" />
                    显示轨迹
                  </>
                )}
              </button>
            </div>
            <RotatingFieldCanvas
              resultantField={resultantField}
              showTrajectory={showTrajectory}
            />
            <div className="mt-3 text-xs text-white/50 text-center">
              合成磁场幅值恒定，方向匀速旋转
            </div>
          </div>
        </div>

        {/* 第三行：同步转速计算 + 原理说明 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 同步转速计算 */}
          <div className="glass-card p-5 animate-fadeIn delay-500">
            <div className="flex items-center gap-2 mb-4">
              <Calculator className="w-5 h-5 text-[#3b82f6]" />
              <h2 className="text-lg font-semibold text-white/90">
                同步转速计算
              </h2>
            </div>
            <SpeedCalculator
              frequency={state.frequency}
              polePairs={state.polePairs}
              syncSpeed={syncSpeed}
            />
          </div>

          {/* 原理说明 */}
          <div className="glass-card p-5 animate-fadeIn delay-500">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-[#8b5cf6]" />
              <h2 className="text-lg font-semibold text-white/90">
                工作原理
              </h2>
            </div>
            <PrincipleExplanation />
          </div>
        </div>
      </main>

      {/* 页脚 */}
      <footer className="border-t border-white/10 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-sm text-white/40">
            <p>旋转磁场产生原理 · 互动式教学资源</p>
            <p className="mt-1">
              三相定子绕组通入相位差120°的交流电，形成空间上依次相差120°的脉振磁场
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
