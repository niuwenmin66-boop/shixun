import { useState, useCallback, useRef, useEffect } from 'react';
import type { AppState, PhaseCurrents, ResultantField } from '@/types';

// 初始状态
const initialState: AppState = {
  frequency: 1,      // 1 Hz
  polePairs: 1,      // 1对极
  amplitude: 1,      // 标幺值
  isPlaying: true,   // 默认播放
  direction: 1,      // 正转
  currentTime: 0,
};

export function useMagneticField() {
  const [state, setState] = useState<AppState>(initialState);
  const animationRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  // 计算三相电流瞬时值
  const calculatePhaseCurrents = useCallback((time: number): PhaseCurrents => {
    const omega = 2 * Math.PI * state.frequency * state.direction;
    const wt = omega * time;
    
    return {
      a: state.amplitude * Math.sin(wt),
      b: state.amplitude * Math.sin(wt - (2 * Math.PI / 3)), // -120°
      c: state.amplitude * Math.sin(wt - (4 * Math.PI / 3)), // -240° (或 +120°)
    };
  }, [state.frequency, state.amplitude, state.direction]);

  // 计算合成磁场
  const calculateResultantField = useCallback((currents: PhaseCurrents): ResultantField => {
    // 三相绕组空间角度 (A相0°, B相-120°, C相-240°)
    const angleA = 0;
    const angleB = -2 * Math.PI / 3; // -120°
    const angleC = -4 * Math.PI / 3; // -240°

    // 分解各相磁场到x-y坐标
    const Fx = currents.a * Math.cos(angleA) + 
               currents.b * Math.cos(angleB) + 
               currents.c * Math.cos(angleC);
    
    const Fy = currents.a * Math.sin(angleA) + 
               currents.b * Math.sin(angleB) + 
               currents.c * Math.sin(angleC);

    // 计算合成磁场的幅值和角度
    const magnitude = Math.sqrt(Fx * Fx + Fy * Fy);
    const angle = Math.atan2(Fy, Fx) * (180 / Math.PI);

    return { magnitude, angle };
  }, []);

  // 计算同步转速
  const calculateSyncSpeed = useCallback((): number => {
    return (60 * state.frequency) / state.polePairs;
  }, [state.frequency, state.polePairs]);

  // 更新频率
  const setFrequency = useCallback((freq: number) => {
    setState(prev => ({ ...prev, frequency: freq }));
  }, []);

  // 更新极对数
  const setPolePairs = useCallback((pairs: number) => {
    setState(prev => ({ ...prev, polePairs: pairs }));
  }, []);

  // 更新电流幅值
  const setAmplitude = useCallback((amp: number) => {
    setState(prev => ({ ...prev, amplitude: amp }));
  }, []);

  // 播放/暂停切换
  const togglePlay = useCallback(() => {
    setState(prev => ({ ...prev, isPlaying: !prev.isPlaying }));
  }, []);

  // 切换旋转方向
  const toggleDirection = useCallback(() => {
    setState(prev => ({ ...prev, direction: prev.direction === 1 ? -1 : 1 }));
  }, []);

  // 重置
  const reset = useCallback(() => {
    setState({
      ...initialState,
      isPlaying: true,
    });
    lastTimeRef.current = 0;
  }, []);

  // 动画循环
  useEffect(() => {
    if (!state.isPlaying) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
      return;
    }

    const animate = (timestamp: number) => {
      if (lastTimeRef.current === 0) {
        lastTimeRef.current = timestamp;
      }
      
      const deltaTime = (timestamp - lastTimeRef.current) / 1000; // 转换为秒
      lastTimeRef.current = timestamp;

      setState(prev => ({
        ...prev,
        currentTime: prev.currentTime + deltaTime,
      }));

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [state.isPlaying]);

  // 计算当前值
  const currents = calculatePhaseCurrents(state.currentTime);
  const resultantField = calculateResultantField(currents);
  const syncSpeed = calculateSyncSpeed();

  return {
    state,
    currents,
    resultantField,
    syncSpeed,
    setFrequency,
    setPolePairs,
    setAmplitude,
    togglePlay,
    toggleDirection,
    reset,
  };
}
