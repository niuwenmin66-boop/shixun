import { useState, useRef, useEffect } from 'react';

export default function AIAssistant() {
  // 消息状态
  const [messages, setMessages] = useState<Array<{role: 'user' | 'assistant', content: string}>>([
    { role: 'assistant', content: '你好！我是你的AI实训小助手，有什么可以帮助你的吗？' }
  ]);
  
  // 输入框内容
  const [inputMessage, setInputMessage] = useState('');
  
  // 加载状态
  const [isLoading, setIsLoading] = useState(false);
  
  // 消息容器引用，用于自动滚动到底部
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 自动滚动到底部
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // 发送消息
  const sendMessage = () => {
    if (!inputMessage.trim() || isLoading) return;

    // 添加用户消息
    const newMessages = [...messages, { role: 'user', content: inputMessage }];
    setMessages(newMessages);
    setInputMessage('');
    setIsLoading(true);

    // 模拟AI回复（实际项目中这里会调用API）
    setTimeout(() => {
      const aiResponse = {
        role: 'assistant',
        content: `感谢你的提问！关于"${inputMessage}"，我可以为你提供以下信息...（这是一个模拟回复，实际应用中会调用真实的AI API）`
      };
      
      setMessages([...newMessages, aiResponse]);
      setIsLoading(false);
    }, 1000);
  };

  // 处理按键事件
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="bg-white rounded-[16px] shadow-[0_8px_24px_rgba(255,143,163,0.12)] flex flex-col h-[calc(100vh-220px)]">
      {/* 头部 */}
      <div className="p-4 border-b border-[var(--light-pink)]">
        <h3 className="text-lg font-semibold text-[var(--text-primary)] flex items-center">
          <i className="fa-solid fa-robot text-[var(--brand-pink)] mr-2"></i>
          AI实训小助手
        </h3>
      </div>

      {/* 消息区域 */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((message, index) => (
          <div 
            key={index} 
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[80%] p-3 rounded-lg ${
                message.role === 'user' 
                  ? 'bg-[var(--brand-pink)] text-white rounded-tr-none' 
                  : 'bg-[var(--bg-primary)] text-[var(--text-primary)] rounded-tl-none border border-[var(--light-pink)]'
              }`}
            >
              <p>{message.content}</p>
            </div>
          </div>
        ))}
        
        {/* 加载状态 */}
        {isLoading && (
          <div className="flex justify-start">
            <div className="max-w-[80%] p-3 rounded-lg bg-[var(--bg-primary)] text-[var(--text-primary)] rounded-tl-none border border-[var(--light-pink)]">
              <div className="flex space-x-1">
                <div className="h-2 w-2 rounded-full bg-[var(--brand-pink)] animate-bounce [animation-delay:-0.3s]"></div>
                <div className="h-2 w-2 rounded-full bg-[var(--brand-pink)] animate-bounce [animation-delay:-0.15s]"></div>
                <div className="h-2 w-2 rounded-full bg-[var(--brand-pink)] animate-bounce"></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* 输入区域 */}
      <div className="p-4 border-t border-[var(--light-pink)]">
        <div className="flex space-x-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="请输入你的问题..."
            className="flex-1 px-4 py-2 rounded-full border border-[var(--light-pink)] focus:outline-none focus:border-[var(--brand-pink)]"
            disabled={isLoading}
          />
          <button
            onClick={sendMessage}
            className="px-4 py-2 rounded-full bg-[var(--brand-pink)] text-white hover:bg-[var(--brand-pink)]/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isLoading || !inputMessage.trim()}
          >
            <i className="fa-solid fa-paper-plane"></i>
          </button>
        </div>
      </div>
    </div>
  );
}