import { useState } from 'react';
import { motion } from 'framer-motion';

// 图片URL常量定义
const trainingImage = "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E6%96%B0%E8%83%BD%E6%BA%90%E6%B1%BD%E8%BD%A6%E7%BB%B4%E4%BF%AE%E8%AE%AD%E7%BB%83%E5%9C%BA%E6%99%AF%EF%BC%8C%E6%9C%BA%E6%A2%B0%E8%BD%A6%E9%97%B4%EF%BC%8C%E4%B8%93%E4%B8%9A%E8%AE%BE%E5%A4%87%EF%BC%8C%E6%8A%80%E6%9C%AF%E4%BA%BA%E5%91%98%E5%9C%A8%E6%93%8D%E4%BD%9C&sign=42db5087903a8d144b64f067c76a5762";
const toolImages = [
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E4%B8%AD%E5%8F%B7%E6%A3%98%E8%BD%AE%E6%89%B3%E6%89%8B%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=f0f7bb9462752e3f94b30cab3ea09de8",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E4%B8%AD%E5%8F%B7%E7%9F%AD%E6%8E%A5%E6%9D%86%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=bba5dbd3f5d6debd821c35aeb459c697",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=13%E5%8F%B7%E5%85%AD%E8%A7%92%E5%A5%97%E7%AD%92%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=2d4f1a96cac44404b09fe5263d306b1c",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=HW4%E9%95%BF%E5%A5%97%E7%AD%92%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=07e75173a380d56134aba791ca5a0505",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=HW6%E9%95%BF%E5%A5%97%E7%AD%92%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=915d518cfb8952765a07bd9bd3fd0a65",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=PDR%E5%A5%97%E7%AD%92%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=d84fd0aefb08764932e8e2157702e986",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E6%A9%A1%E8%83%B6%E9%94%A4%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=94e0b4670aa4abfc01a14b3a3e6d5324",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%90%B8%E5%8A%9B%E6%B3%B5%EF%BC%8C%E4%B8%93%E4%B8%9A%E7%BB%B4%E4%BF%AE%E5%B7%A5%E5%85%B7&sign=1ce2eb5d43b0397a5865faddea4813d6",
];
const materialImages = [
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%BC%B9%E6%80%A7%E5%9E%AB%E5%9C%88%EF%BC%8C%E6%9C%BA%E6%A2%B0%E9%9B%B6%E4%BB%B6&sign=408185e2a3778af68a2c0b02a82ed839",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%9E%AB%E7%89%87%EF%BC%8C%E6%9C%BA%E6%A2%B0%E9%9B%B6%E4%BB%B6&sign=277cfbc097698768bd709921eac9c1ab",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E5%BC%B9%E6%80%A7%E6%8C%A1%E5%9C%88%EF%BC%8C%E6%9C%BA%E6%A2%B0%E9%9B%B6%E4%BB%B6&sign=7f75b35996ec27b8c5a097e27f570bff",
];
const workplaceImage = "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%B1%BD%E8%BD%A6%E7%BB%B4%E4%BF%AE%E5%B7%A5%E4%BD%8D%EF%BC%8C%E6%95%B4%E6%B4%81%E6%9C%89%E5%BA%8F%E7%9A%84%E5%B7%A5%E4%BD%9C%E5%8F%B0%EF%BC%8C%E5%B7%A5%E5%85%B7%E6%91%86%E6%94%BE%E6%95%B4%E9%BD%90&sign=764cd3b20f140858137c493eb0824f93";
const safetyImage = "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%B1%BD%E8%BD%A6%E7%BB%B4%E4%BF%AE%E5%AE%89%E5%85%A8%E6%93%8D%E4%BD%9C%EF%BC%8C%E6%8A%80%E6%9C%AF%E4%BA%BA%E5%91%98%E7%A9%BF%E6%88%B4%E9%98%B2%E6%8A%A4%E8%A3%85%E5%A4%87&sign=80e79be52f384aa05217c8076202414b";

// 步骤图片定义
const stepImages = [
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%8B%86%E5%8D%B8%E4%B8%89%E7%9B%B8%E7%BA%BF%E6%9D%9F%E8%BF%9E%E6%8E%A5%E5%99%A8%E5%9B%BA%E5%AE%9A%E8%9E%BA%E6%AF%8D%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=d149e41b311eac5bcc526a8d2e90aa6d",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E5%8F%96%E4%B8%8B%E4%B8%89%E7%9B%B8%E7%BA%BF%E6%9D%9F%E6%8E%A5%E5%A4%B4%E5%8F%8A%E7%9B%B8%E5%85%B3%E9%83%A8%E4%BB%B6%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=d2eb6fa4e38a1a6f805b825daaa557b2",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%9D%BE%E5%BC%80%E5%B9%B6%E5%8F%96%E5%87%BA%E4%B8%89%E7%9B%B8%E4%BA%A4%E6%B5%81%E7%BA%BF%E6%9D%9F%E8%BF%9E%E6%8E%A5%E5%99%A8%E5%9B%BA%E5%AE%9A%E8%9E%BA%E6%A0%93%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=4ca1962d8d258b8f18baff8f03be4dc4",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E5%8F%96%E4%B8%8B%E4%B8%89%E7%9B%B8%E4%BA%A4%E6%B5%81%E7%BA%BF%E6%9D%9F%E8%BF%9E%E6%8E%A5%E5%99%A8%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=892ce1b76b56926571dfa2c3a535f91a",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%8B%86%E5%8D%B8%E7%94%B5%E6%9C%BA%E9%80%9F%E5%BA%A6%E7%BC%96%E7%A0%81%E5%99%A8%E7%9B%96%E6%9D%BF%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=6d06b181f61ee634a2886d8161fe4b91",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%8B%86%E5%8D%B8%E7%94%B5%E6%9C%BA%E9%80%9F%E5%BA%A6%E7%BC%96%E7%A0%81%E5%99%A8%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=3590da36b58c5cce52d2e771873bab59",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%8B%86%E5%8D%B8%E8%BD%B4%E6%89%BF%E5%BA%95%E5%BA%A7%E5%9B%BA%E5%AE%9A%E8%9E%BA%E6%A0%93%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=21417ef0d8857f1599f217a3c0c29c35",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%9D%BE%E5%BC%80%E5%90%8E%E7%AB%AF%E7%9B%96%E5%9B%BA%E5%AE%9A%E8%9E%BA%E6%A0%93%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=35bd4cbb7fcfdf751e542a3300fb1777",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E5%8F%96%E5%87%BA%E5%90%8E%E7%AB%AF%E7%9B%96%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=a3358906cfee4b68086db8e1742a399d",
  "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=%E6%8B%86%E5%8D%B8%E8%BD%AC%E5%AD%90%E5%89%8D%E7%AB%AF%E5%BC%B9%E6%80%A7%E6%8C%A1%E5%9C%88%E7%9A%84%E6%93%8D%E4%BD%9C%E6%AD%A5%E9%AA%A4&sign=9edc5318f96c1b1a9dd5ab7565b91867",
];

export default function TrainingGuide() {
  // 展开/折叠状态管理
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    intro: true,
    skills: false,
    scenario: false,
    preparation: false,
    steps: true,
    conclusion: false,
  });
  
  // 放大图片预览状态
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  // 切换章节展开/折叠
  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  // 关闭图片预览
  const closeImagePreview = () => {
    setSelectedImage(null);
  };

  return (
    <div className="bg-white rounded-[16px] shadow-[0_8px_24px_rgba(255,143,163,0.12)] p-6 h-[calc(100vh-220px)] overflow-y-auto">
      {/* 标题 */}
      <h1 className="text-2xl font-semibold mb-6 text-[var(--text-primary)] border-b border-[var(--light-pink)] pb-3">
        交流异步电机拆卸实训
      </h1>

      {/* 实训介绍 */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('intro')}
          className="w-full flex items-center justify-between text-lg font-medium mb-3 text-[var(--text-primary)]"
        >
          <span>实训介绍</span>
          <i className={`fa-solid fa-chevron-down transition-transform duration-200 ${expandedSections.intro ? 'transform rotate-180' : ''}`}></i>
        </button>
        
        {expandedSections.intro && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="pl-1"
          >
            <p className="text-[var(--text-primary)] leading-relaxed">
              交流异步电机拆卸实训是电工、机电设备类专业的核心实操实训之一，主要围绕交流异步电机的核心部件拆卸展开，涵盖工具规范使用、关键部件无损拆卸、安全操作等核心内容。通过本实训，可帮助学习者掌握电机拆卸的标准流程与关键技巧，培养规范操作习惯和质量意识，夯实电机运维、检修相关岗位的技能基础，为后续职业技能提升及对应职业技能认证衔接奠定坚实实操基础。
            </p>
          </motion.div>
        )}
      </div>

      {/* 技能、岗位与技能认证 */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('skills')}
          className="w-full flex items-center justify-between text-lg font-medium mb-3 text-[var(--text-primary)]"
        >
          <span>技能、岗位与技能认证</span>
          <i className={`fa-solid fa-chevron-down transition-transform duration-200 ${expandedSections.skills ? 'transform rotate-180' : ''}`}></i>
        </button>
        
        {expandedSections.skills && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="space-y-4 pl-1"
          >
            <div className="bg-[var(--bg-primary)] rounded-lg p-4">
              <h4 className="font-medium mb-2 flex items-center">
                <span className="text-[var(--brand-pink)] mr-2">1.</span> 
                对角交叉法拆卸螺栓
              </h4>
              <div className="ml-4 space-y-2 text-sm">
                <p><strong className="text-[var(--text-primary)]">技能要求：</strong> <span className="text-[var(--text-secondary)]">轴承底座、后端盖、线束连接器等部位必须使用对角均匀松动，防止端盖变形、受力不均、裂纹。易损件识别与处理。明确：弹性垫圈、垫片、弹性挡圈不可重复使用，安装必须换新。这是电机装配质量与寿命的关键。</span></p>
                <p><strong className="text-[var(--text-primary)]">对应岗位：</strong> <span className="text-[var(--text-secondary)]">设备维修工（电机方向）；电气运维工；电机装配与调试</span></p>
                <p><strong className="text-[var(--text-primary)]">技能认证：</strong></p>
                <ul className="list-disc list-inside ml-4 text-[var(--text-secondary)]">
                  <li>国家职业技能等级认证：维修电工（中级 / 四级及以上）；机电设备安装与维修（中级及以上）</li>
                  <li>行业职业技能认证：制造业企业：设备维修工（电机方向）；电力 / 机电运维企业：电气运维工；专用设备企业：电机装配与调试工</li>
                  <li>企业技能等级认证：核心考核点，是电机拆装类认证的必备实操技能，防止部件受力不均变形，适配各认证中电机拆装相关考核内容</li>
                </ul>
              </div>
            </div>

            <div className="bg-[var(--bg-primary)] rounded-lg p-4">
              <h4 className="font-medium mb-2 flex items-center">
                <span className="text-[var(--brand-pink)] mr-2">2.</span> 
                橡胶锤轻敲拆卸后端盖
              </h4>
              <div className="ml-4 space-y-2 text-sm">
                <p><strong className="text-[var(--text-primary)]">技能要求：</strong> <span className="text-[var(--text-secondary)]">禁止硬敲硬砸，掌握轻敲四角、均匀受力的技巧。保护端盖平面、止口、轴承。精密部件（编码器）无损拆卸。编码器拆卸顺序、固定片取出、轻拿轻放。不磕碰、不拉扯线路，是核心技能。</span></p>
                <p><strong className="text-[var(--text-primary)]">对应岗位：</strong> <span className="text-[var(--text-secondary)]">设备维修工（电机方向）；电机装配与调试工</span></p>
                <p><strong className="text-[var(--text-primary)]">技能认证：</strong></p>
                <ul className="list-disc list-inside ml-4 text-[var(--text-secondary)]">
                  <li>国家职业技能等级认证：维修电工（中级 / 四级及以上）；机电设备安装与维修（中级及以上）</li>
                  <li>行业职业技能认证：电机检修工（初级及以上）；工业机器人操作与运维（1+X 证书）</li>
                  <li>企业技能等级认证：制造业企业：设备维修工（电机方向）；专用设备企业：电机装配与调试工</li>
                </ul>
              </div>
            </div>

            {/* 其他技能项可以类似添加 */}
          </motion.div>
        )}
      </div>

      {/* 实训场景案例 */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('scenario')}
          className="w-full flex items-center justify-between text-lg font-medium mb-3 text-[var(--text-primary)]"
        >
          <span>实训场景案例</span>
          <i className={`fa-solid fa-chevron-down transition-transform duration-200 ${expandedSections.scenario ? 'transform rotate-180' : ''}`}></i>
        </button>
        
        {expandedSections.scenario && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="pl-1"
          >
            <div className="bg-[var(--bg-primary)] rounded-lg p-4">
              <p className="text-[var(--text-primary)] leading-relaxed mb-4">
                某新能源汽车维修车间接收了一辆需要电机检修的电动汽车。经初步检测，发现电机存在异常噪音和振动问题，技术主管决定进行电机拆卸检修。作为维修实习生，你需要在师傅的指导下，按照标准流程完成交流异步电机的拆卸工作。这是你第一次独立操作此类任务，需要特别注意操作规范和安全要求...
              </p>
              <div 
                className="relative rounded-lg overflow-hidden cursor-pointer"
                onClick={() => setSelectedImage(trainingImage)}
              >
                <img 
                  src={trainingImage} 
                  alt="实训场景" 
                  className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                  <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* 实训准备 */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('preparation')}
          className="w-full flex items-center justify-between text-lg font-medium mb-3 text-[var(--text-primary)]"
        >
          <span>实训准备</span>
          <i className={`fa-solid fa-chevron-down transition-transform duration-200 ${expandedSections.preparation ? 'transform rotate-180' : ''}`}></i>
        </button>
        
        {expandedSections.preparation && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="space-y-4 pl-1"
          >
            {/* 工具准备 */}
            <div>
              <h4 className="font-medium mb-3 flex items-center">
                <i className="fa-solid fa-toolbox text-[var(--brand-pink)] mr-2"></i>
                工具准备
              </h4>
              <div className="grid grid-cols-4 gap-3">
                {['中号棘轮扳手', '中号短接杆', '13号六角套筒', 'HW4长套筒', 'HW6长套筒', 'PDR套筒', '橡胶锤', '吸力泵'].map((tool, index) => (
                  <div 
                    key={index} 
                    className="bg-white border border-[var(--light-pink)] rounded-lg p-2 text-center cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedImage(toolImages[index])}
                  >
                    <div className="mb-2 relative rounded overflow-hidden h-24">
                      <img 
                        src={toolImages[index]} 
                        alt={tool} 
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                    </div>
                    <p className="text-sm text-[var(--text-secondary)]">{tool}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* 物料准备 */}
            <div>
              <h4 className="font-medium mb-3 flex items-center">
                <i className="fa-solid fa-box-open text-[var(--brand-pink)] mr-2"></i>
                物料准备
              </h4>
              <div className="grid grid-cols-4 gap-3">
                {['弹性垫圈', '垫片', '弹性挡圈'].map((material, index) => (
                  <div 
                    key={index} 
                    className="bg-white border border-[var(--light-pink)] rounded-lg p-2 text-center cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedImage(materialImages[index])}
                  >
                    <div className="mb-2 relative rounded overflow-hidden h-24">
                      <img 
                        src={materialImages[index]} 
                        alt={material} 
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                    </div>
                    <p className="text-sm text-[var(--text-secondary)]">{material}</p>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-sm text-[var(--text-secondary)]">
                注意：准备新的弹性垫圈、垫片、弹性挡圈。这些部件不可重复使用，安装时必须换新。
              </p>
            </div>

            {/* 工位整理 */}
            <div>
              <h4 className="font-medium mb-3 flex items-center">
                <i className="fa-solid fa-screwdriver-wrench text-[var(--brand-pink)] mr-2"></i>
                工位整理
              </h4>
              <div 
                className="relative rounded-lg overflow-hidden cursor-pointer"
                onClick={() => setSelectedImage(workplaceImage)}
              >
                <img 
                  src={workplaceImage} 
                  alt="工位整理" 
                  className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                  <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                </div>
              </div>
              <p className="mt-2 text-sm text-[var(--text-secondary)]">
                清理实训台面，划分部件摆放区域，避免拆卸后部件丢失、混用。
              </p>
            </div>

            {/* 安全提示 */}
            <div>
              <h4 className="font-medium mb-3 flex items-center">
                <i className="fa-solid fa-shield-alt text-[var(--brand-pink)] mr-2"></i>
                安全提示
              </h4>
              <div 
                className="relative rounded-lg overflow-hidden cursor-pointer"
                onClick={() => setSelectedImage(safetyImage)}
              >
                <img 
                  src={safetyImage} 
                  alt="安全提示" 
                  className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                  <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                </div>
              </div>
              <p className="mt-2 text-sm text-[var(--text-secondary)]">
                穿戴好实训防护用品，明确禁止野蛮操作。
              </p>
            </div>

            {/* 实训时长 */}
            <div className="bg-[var(--bg-primary)] rounded-lg p-4 flex items-center">
              <i className="fa-solid fa-clock text-[var(--brand-pink)] text-xl mr-3"></i>
              <div>
                <p className="font-medium">实训时长</p>
                <p className="text-sm text-[var(--text-secondary)]">90分钟</p>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* 实操步骤 */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('steps')}
          className="w-full flex items-center justify-between text-lg font-medium mb-3 text-[var(--text-primary)]"
        >
          <span>实操步骤</span>
          <i className={`fa-solid fa-chevron-down transition-transform duration-200 ${expandedSections.steps ? 'transform rotate-180' : ''}`}></i>
        </button>
        
        {expandedSections.steps && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="pl-1"
          >
            {/* 步骤一 */}
            <div className="mb-6">
              <h3 className="text-xl font-medium mb-4 text-[var(--text-primary)] bg-[var(--bg-primary)] px-4 py-2 rounded-lg">
                步骤一：三相线束连接器拆卸
              </h3>
              
              <div className="space-y-6 ml-4">
                {/* 子步骤1 */}
                <div className="bg-white border border-[var(--light-pink)] rounded-lg p-4">
                  <h4 className="font-medium mb-3 text-[var(--text-primary)]">① 拆卸三相线束连接器固定螺母</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong className="text-[var(--text-primary)]">工具选用：</strong> <span className="text-[var(--text-secondary)]">中号棘轮扳手、中号短接杆、13号六角套筒。</span></p>
                    <p><strong className="text-[var(--text-primary)]">操作要点：</strong> <span className="text-[var(--text-secondary)]">用上述工具松开三相线束连接器固定螺母，依次取下螺母、弹性垫圈和垫片。</span></p>
                    <p><strong className="text-[var(--text-primary)]">注意事项：</strong> <span className="text-[var(--text-secondary)]">明确弹性垫圈和垫片不可重复使用，做好标记，提醒后续安装时更换新品。</span></p>
                    <p><strong className="text-[var(--text-primary)]">技能标注：</strong> <span className="text-[var(--text-secondary)]">基础技能（工具匹配、部件有序拆卸）</span></p>
                  </div>
                  <div 
                    className="mt-3 relative rounded-lg overflow-hidden cursor-pointer"
                    onClick={() => setSelectedImage(stepImages[0])}
                  >
                    <img 
                      src={stepImages[0]} 
                      alt="拆卸三相线束连接器固定螺母" 
                      className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                    </div>
                  </div>
                </div>

                {/* 子步骤2 */}
                <div className="bg-white border border-[var(--light-pink)] rounded-lg p-4">
                  <h4 className="font-medium mb-3 text-[var(--text-primary)]">② 取下三相线束接头及相关部件</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong className="text-[var(--text-primary)]">操作要点：</strong> <span className="text-[var(--text-secondary)]">分别取下三相线束接头和下端垫片，将取下的部件按类别摆放在指定区域，做好区分标记。</span></p>
                    <p><strong className="text-[var(--text-primary)]">注意事项：</strong> <span className="text-[var(--text-secondary)]">避免线束拉扯、弯折，防止线束绝缘层破损。</span></p>
                    <p><strong className="text-[var(--text-primary)]">技能标注：</strong> <span className="text-[var(--text-secondary)]">基础技能（部件规范摆放、线束保护）</span></p>
                  </div>
                  <div 
                    className="mt-3 relative rounded-lg overflow-hidden cursor-pointer"
                    onClick={() => setSelectedImage(stepImages[1])}
                  >
                    <img 
                      src={stepImages[1]} 
                      alt="取下三相线束接头及相关部件" 
                      className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                    </div>
                  </div>
                </div>

                {/* 子步骤3 */}
                <div className="bg-white border border-[var(--light-pink)] rounded-lg p-4">
                  <h4 className="font-medium mb-3 text-[var(--text-primary)]">③ 松开并取出三相交流线束连接器固定螺栓</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong className="text-[var(--text-primary)]">工具选用：</strong> <span className="text-[var(--text-secondary)]">中号棘轮扳手、HW4长套筒。</span></p>
                    <p><strong className="text-[var(--text-primary)]">操作要点：</strong> <span className="text-[var(--text-secondary)]">采用对角交叉的方式，均匀松开三相交流线束连接器固定螺栓，松开后取出螺栓及垫片。</span></p>
                    <p><strong className="text-[var(--text-primary)]">注意事项：</strong> <span className="text-[var(--text-secondary)]">对角交叉松开时，力度均匀，避免螺栓滑丝、螺纹损坏。</span></p>
                    <p><strong className="text-[var(--text-primary)]">技能标注：</strong> <span className="text-[var(--warning-orange)] font-medium">★关键技能（对角交叉拆卸螺栓方法，防止部件受力不均）</span></p>
                  </div>
                  <div 
                    className="mt-3 relative rounded-lg overflow-hidden cursor-pointer"
                    onClick={() => setSelectedImage(stepImages[2])}
                  >
                    <img 
                      src={stepImages[2]} 
                      alt="松开并取出三相交流线束连接器固定螺栓" 
                      className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                    </div>
                  </div>
                </div>

                {/* 其他子步骤可以类似添加 */}
              </div>
            </div>

            {/* 步骤二到步骤四可以类似添加 */}
            <div className="mb-6">
              <h3 className="text-xl font-medium mb-4 text-[var(--text-primary)] bg-[var(--bg-primary)] px-4 py-2 rounded-lg">
                步骤二：电机速度编码器拆卸
              </h3>
              
              <div className="space-y-6 ml-4">
                {/* 子步骤1 */}
                <div className="bg-white border border-[var(--light-pink)] rounded-lg p-4">
                  <h4 className="font-medium mb-3 text-[var(--text-primary)]">① 拆卸电机速度编码器盖板</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong className="text-[var(--text-primary)]">工具选用：</strong> <span className="text-[var(--text-secondary)]">中号棘轮扳手、中号短接杆、PDR套筒。</span></p>
                    <p><strong className="text-[var(--text-primary)]">操作要点：</strong> <span className="text-[var(--text-secondary)]">用上述工具松开电机速度编码器盖板固定螺栓，依次取下螺栓和盖板。</span></p>
                    <p><strong className="text-[var(--text-primary)]">注意事项：</strong> <span className="text-[var(--text-secondary)]">取下盖板时，轻拿轻放，避免盖板变形，防止灰尘进入编码器内部。</span></p>
                    <p><strong className="text-[var(--text-primary)]">技能标注：</strong> <span className="text-[var(--text-secondary)]">基础技能（盖板无损拆卸、精密部件防尘保护）</span></p>
                  </div>
                  <div 
                    className="mt-3 relative rounded-lg overflow-hidden cursor-pointer"
                    onClick={() => setSelectedImage(stepImages[4])}
                  >
                    <img 
                      src={stepImages[4]} 
                      alt="拆卸电机速度编码器盖板" 
                      className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                    </div>
                  </div>
                </div>

                {/* 子步骤2 */}
                <div className="bg-white border border-[var(--light-pink)] rounded-lg p-4">
                  <h4 className="font-medium mb-3 text-[var(--text-primary)]">② 拆卸电机速度编码器</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong className="text-[var(--text-primary)]">工具选用：</strong> <span className="text-[var(--text-secondary)]">中号棘轮扳手、HW4长套筒。</span></p>
                    <p><strong className="text-[var(--text-primary)]">操作要点：</strong> <span className="text-[var(--text-secondary)]">用工具松开电机速度编码器固定螺栓，取出螺栓和左右两侧固定片，随后平稳取下电机速度编码器。</span></p>
                    <p><strong className="text-[var(--text-primary)]">注意事项：</strong> <span className="text-[var(--text-secondary)]">拆卸过程中，不磕碰、不硬撬编码器，避免编码器内部元件损坏；固定片做好摆放标记，防止混淆。</span></p>
                    <p><strong className="text-[var(--text-primary)]">技能标注：</strong> <span className="text-[var(--warning-orange)] font-medium">★关键技能（编码器无损拆卸，精密部件保护技巧）</span></p>
                  </div>
                  <div 
                    className="mt-3 relative rounded-lg overflow-hidden cursor-pointer"
                    onClick={() => setSelectedImage(stepImages[5])}
                  >
                    <img 
                      src={stepImages[5]} 
                      alt="拆卸电机速度编码器" 
                      className="w-full h-auto object-cover hover:opacity-90 transition-opacity"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/10 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <i className="fa-solid fa-search-plus text-white text-2xl"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* 实训收尾 */}
      <div className="mb-6">
        <button
          onClick={() => toggleSection('conclusion')}
          className="w-full flex items-center justify-between text-lg font-medium mb-3 text-[var(--text-primary)]"
        >
          <span>实训收尾</span>
          <i className={`fa-solid fa-chevron-down transition-transform duration-200 ${expandedSections.conclusion ? 'transform rotate-180' : ''}`}></i>
        </button>
        
        {expandedSections.conclusion && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="pl-1"
          >
            <div className="bg-[var(--bg-primary)] rounded-lg p-4 space-y-3">
              <div className="flex">
                <i className="fa-solid fa-check-circle text-[var(--success-green)] mt-1 mr-3"></i>
                <p className="text-[var(--text-primary)]"><strong>部件整理：</strong>将所有拆卸下来的部件（螺栓、垫片、盖板、编码器等）按类别、按拆卸顺序摆放整齐，做好标记，区分可重复使用件和需更换的易损件。</p>
              </div>
              <div className="flex">
                <i className="fa-solid fa-check-circle text-[var(--success-green)] mt-1 mr-3"></i>
                <p className="text-[var(--text-primary)]"><strong>工具归位：</strong>将使用后的工具清洁干净，按规格放回指定存放处，检查工具是否完好。</p>
              </div>
              <div className="flex">
                <i className="fa-solid fa-check-circle text-[var(--success-green)] mt-1 mr-3"></i>
                <p className="text-[var(--text-primary)]"><strong>工位清洁：</strong>清理实训台面的杂物、灰尘，保持工位整洁。</p>
              </div>
              <div className="flex">
                <i className="fa-solid fa-check-circle text-[var(--success-green)] mt-1 mr-3"></i>
                <p className="text-[var(--text-primary)]"><strong>记录填写：</strong>填写实训记录，注明拆卸过程中遇到的问题、易损件更换情况及操作体会。</p>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* 图片预览模态框 */}
      {selectedImage && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={closeImagePreview}
        >
          <div className="relative max-w-4xl max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
            <button
              className="absolute -top-12 right-0 text-white text-2xl hover:text-gray-300"
              onClick={closeImagePreview}
            >
              <i className="fa-solid fa-times"></i>
            </button>
            <img 
              src={selectedImage} 
              alt="预览图片" 
              className="max-w-full max-h-[90vh] object-contain rounded-lg"
            />
          </div>
        </motion.div>
      )}
    </div>
  );
}